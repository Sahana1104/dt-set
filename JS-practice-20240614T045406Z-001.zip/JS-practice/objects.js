let pnerso = {
    fn: 'Vijay',
    ln: 'Bala',
    deg: 'BTech',
    phno: '1234567890'
};
console.log(person.fn);