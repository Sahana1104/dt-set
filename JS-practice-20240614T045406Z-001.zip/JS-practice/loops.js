let planets = ['Mercury', 'Venus', 'Earth'];
for (let i=0; i < planets.length; i++){
    console.log(planets[i]);
}