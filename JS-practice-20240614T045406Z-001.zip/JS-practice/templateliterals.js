let name = 'Evanjelin';
let message = 'Good work, ${name}!';
console.log(message);