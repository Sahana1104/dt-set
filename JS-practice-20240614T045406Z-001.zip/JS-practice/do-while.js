let count = 0;
do {
    console,log(count);
    count++;
} while (count < 5);