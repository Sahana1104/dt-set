let fruit = 'Apple';
switch (fruit) {
    case 'Pineapple':
        console.log('Pineapple is yellow');
        break;
    case 'Apple':
        console.log('Apple is red');
    default:
        console.log('Unknow fruit');        
}