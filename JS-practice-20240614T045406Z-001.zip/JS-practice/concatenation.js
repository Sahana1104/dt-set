let fn = 'Vijay';
let ln = 'Bala';
let fulln = fn + '' + ln;
console.log(fulln);