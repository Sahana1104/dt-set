function welcome(world = 'Earth') {
    return 'Hello' + world;
}
console.log(welcome())