let r = 2;
const pi = 3.14;
let areat = pi*r*r;
console.log(areat);