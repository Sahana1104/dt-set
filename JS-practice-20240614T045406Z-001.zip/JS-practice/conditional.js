let number = 10;
if (number > 5){
    console.log('This number is greater thean 5');
} else {
    console.log('This number is 5 or less');
}