let numbers = [1, 2, 3, 4, 5];
let doubled = number.map(n => n*2);
console.log(doubled);