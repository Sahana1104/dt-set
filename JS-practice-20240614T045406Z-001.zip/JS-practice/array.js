let planets = ['Mercury', 'Venus', 'Earth'];
console.log(planets[2]);