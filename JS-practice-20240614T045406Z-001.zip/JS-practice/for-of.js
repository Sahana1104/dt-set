let fruits = ['Apple', 'Cherry', 'Kiwi'];
for (let fruit of fruits) {
    console.log(fruit);
}