function welcome(world){
    return 'Hello' + world;
}
console.log(welcome('Earth'));